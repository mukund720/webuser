﻿using Microsoft.EntityFrameworkCore;
using WebUser.DataModel;

namespace WebUser.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
       : base(options)
        {
        }

        // Define DbSet properties for your entities
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure entity mappings and relationships here
            // e.g., modelBuilder.Entity<YourEntity>().ToTable("YourTableName");
        }
    }
}
